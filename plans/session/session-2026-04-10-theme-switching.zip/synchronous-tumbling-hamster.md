# Plan: Dynamické přepínání theme — QS + Lua komponenty

## Context

Při přepnutí theme přes wallpaper picker se barvy QS komponent (dashboard, OSD, control panel…) ani Lua exit screen neaktualizují. Uživatel chce, aby to fungovalo stejně jako wibox widgety, které se aktualizují přes `data::theme` broker signál.

**Kořenové příčiny:**
1. `theme.json` (zdroj barev pro QS) vůbec neexistuje na disku — `theme-export.sh` se nikdy nespustí při startu
2. `theme-export.sh` sice funguje při `switchTheme()`, ale `theme.default.json` (fallback) není deploynutý
3. Lua exit screen cachuje barvy při `init()` a nemá `data::theme` handler
4. rc.lua clock + calendar mají hardcoded barvy

## Řešení

### Krok 1: Opravit deploy.sh (deploy theme-export infrastruktury)

**Soubor:** `plans/project/somewm-shell/deploy.sh`

Problém: `--exclude '*.default.json'` blokuje deploy `theme.default.json` (fallback pro theme-export.sh).

Změny:
1. Změnit exclude z `'*.default.json'` na `'config.default.json'` — tím se `theme.default.json` zahrne do rsync
2. Přidat seedování `theme.json` — pokud `~/.config/somewm/themes/default/theme.json` neexistuje, spustit `theme-export.sh` (nebo kopírovat fallback)

```bash
# Řádek 15+23: změnit exclude
--exclude 'config.default.json'

# Za řádek 29: seed theme.json při prvním deployi
THEME_JSON="$HOME/.config/somewm/themes/default/theme.json"
if [[ ! -f "$THEME_JSON" ]]; then
    mkdir -p "$(dirname "$THEME_JSON")"
    # Zkusit živý export, fallback na default
    bash "$TARGET/theme-export.sh" 2>/dev/null || \
        cp "$TARGET/theme.default.json" "$THEME_JSON" 2>/dev/null
    echo "Seeded theme.json"
fi
```

### Krok 2: Spustit theme-export na startu QS

**Soubor:** `plans/project/somewm-shell/services/Wallpapers.qml`

Řádek 529-531 — `Component.onCompleted` volá jen `refresh()`, ale nikdy `themeExportProc`.

```qml
Component.onCompleted: {
    themeExportProc.running = true   // PŘIDAT — sync barvy z kompozitoru
    refresh()
}
```

Tím se `theme.json` aktualizuje z aktuálního stavu `beautiful.*` při každém startu QS.

### Krok 3: Exit screen — dynamický rebuild na theme switch

**Soubor:** `plans/project/somewm-one/fishlive/exit_screen.lua`

Exit screen cachuje barvy v `M._state.cfg` při `init()` (řádek 271). `make_button()` vytváří rubato animace s uzavřenými referencemi na config — nelze jednoduše aktualizovat in-place.

**Přístup: Full rebuild** — exit screen je on-demand (ne vždy viditelný), takže rebuild je nejspolehlivější.

Změny:
1. Přesunout `awesome.connect_signal` volání (řádky 373-375) do guardu `_signals_connected`, aby se neregistrovaly duplicitně
2. Přidat `broker.connect_signal("data::theme")` handler, který zruší starý wibox a zavolá `M.init()` znovu

```lua
-- Na konci M.init(), místo řádků 373-375:
if not M._state._signals_connected then
    M._state._signals_connected = true
    awesome.connect_signal("exit_screen::open", open)
    awesome.connect_signal("exit_screen::close", close)
    awesome.connect_signal("exit_screen::toggle", toggle)

    local broker = require("fishlive.broker")
    broker.connect_signal("data::theme", function()
        if M._state.exit_wb then
            M._state.exit_wb.visible = false
            M._state.exit_wb = nil
        end
        if M._state.grabber then
            M._state.grabber:stop()
            M._state.grabber = nil
        end
        M._state.initialized = false
        M._state.cfg = {}
        M.init()
    end)
end
```

Klíčové: `open`, `close`, `toggle` jsou module-level locals, čtou z `M._state` — po rebuildu automaticky vidí nové hodnoty.

### Krok 4: rc.lua — dynamické barvy pro clock + calendar

**Soubor:** `plans/project/somewm-one/rc.lua`

**Clock (řádky 202-205):** Nahradit hardcoded `#b0b0b0`/`#e2b55a` za `beautiful.fg_normal`/`beautiful.border_color_active`, přidat `data::theme` handler pro refresh formátu.

```lua
local function clock_format()
    return '<span foreground="' .. (beautiful.fg_normal or "#b0b0b0")
        .. '" font="Geist 10"> %a %d %b</span>'
        .. '<span foreground="' .. (beautiful.border_color_active or "#e2b55a")
        .. '" font="Geist SemiBold 11"> %H:%M </span>'
end
mytextclock = wibox.widget.textclock(clock_format(), 60)

local broker = require("fishlive.broker")
broker.connect_signal("data::theme", function()
    mytextclock:set_format(clock_format())
end)
```

**Calendar popup (řádky 208-235):** Zabalit do factory funkce, na `data::theme` zrušit starý a vytvořit nový.

```lua
local function create_cal_popup()
    return awful.widget.calendar_popup.month({
        start_sunday = false,
        long_weekdays = true,
        style_month = {
            bg_color     = (beautiful.bg_normal or "#181818") .. "f0",
            border_color = beautiful.border_color_active or "#e2b55a",
            border_width = 1,
            padding      = dpi(10),
        },
        style_header = { fg_color = beautiful.border_color_active or "#e2b55a", font = "Geist SemiBold 12" },
        style_weekday = { fg_color = beautiful.fg_normal or "#888888", font = "Geist 10" },
        style_normal = { fg_color = beautiful.fg_focus or "#d4d4d4", font = "Geist 10" },
        style_focus = {
            fg_color = beautiful.bg_normal or "#181818",
            bg_color = beautiful.border_color_active or "#e2b55a",
            font = "Geist Bold 10",
            shape = gears.shape.circle,
        },
    })
end

cal_popup = create_cal_popup()
broker.connect_signal("data::theme", function()
    cal_popup = create_cal_popup()
end)
```

## Kritické soubory

| Soubor | Změna |
|--------|-------|
| `plans/project/somewm-shell/deploy.sh` | Opravit exclude, přidat theme.json seed |
| `plans/project/somewm-shell/services/Wallpapers.qml` | Přidat `themeExportProc` do `onCompleted` |
| `plans/project/somewm-one/fishlive/exit_screen.lua` | Přidat `data::theme` handler s full rebuild |
| `plans/project/somewm-one/rc.lua` | Dynamické barvy pro clock + calendar |

## Ověření

1. **QS barvy na startu:** Po deployi `theme.json` existuje, QS barvy odpovídají aktivnímu theme
2. **QS barvy po switchi:** Přepnout theme v pickeru → všechny QS komponenty (dashboard border, OSD, control panel slidery) změní barvy do ~500ms
3. **Exit screen:** Přepnout theme → `Super+Q` → tlačítka mají nové accent/fg barvy
4. **Clock + calendar:** Přepnout theme → wibar hodiny + calendar popup používají nové barvy
5. **Fallback:** Smazat theme.json, restartovat QS → seeduje se z fallbacku, barvy OK
