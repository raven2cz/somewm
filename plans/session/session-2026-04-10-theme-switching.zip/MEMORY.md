# Memory Index

- [feedback_install_script.md](feedback_install_script.md) — Always use install-scenefx.sh, never sudo make install
- [feedback_gemini_model.md](feedback_gemini_model.md) — Always use gemini-3.1-pro-preview model with gemini CLI
- [project_client_animations.md](project_client_animations.md) — Client animation + scenefx integration complete, upstream issues #381 and #387
- [project_focus_regression.md](project_focus_regression.md) — Focus/pointer regression from upstream merge 9b543b0 (resolved)
- [feedback_deploy_restart.md](feedback_deploy_restart.md) — Always auto-deploy + restart QS after shell changes
- [feedback_qs_deploy.md](feedback_qs_deploy.md) — Two deploy scripts: somewm-one for rc.lua, somewm-shell for QS. Never confuse them.
- [feedback_upstream_pr_workflow.md](feedback_upstream_pr_workflow.md) — Upstream PRs must branch from upstream/main, never from our divergent fork main
- [feedback_no_claude_footer.md](feedback_no_claude_footer.md) — Never add "Generated with Claude Code" footer to upstream PRs
- [feedback_never_deploy_live.md](feedback_never_deploy_live.md) — CRITICAL: never deploy/reload untested code to live compositor, always sandbox first
- [feedback_wallpaper_apply.md](feedback_wallpaper_apply.md) — apply_wallpaper must create new awful.wallpaper each time, never reuse widget
