---
name: QS shell deploy workflow
description: Always use plans/project/somewm-shell/deploy.sh for QS changes, then kill+respawn QS
type: feedback
---

Two separate deploy scripts exist — NEVER confuse them:

1. `plans/project/somewm-one/deploy.sh` → deploys rc.lua + themes to `~/.config/somewm/`
2. `plans/project/somewm-shell/deploy.sh` → deploys QS shell to `~/.config/quickshell/somewm/`

**Why:** QS reads from `~/.config/quickshell/somewm/`, NOT from `plans/project/somewm-shell/`. Editing files in `plans/project/somewm-shell/` does nothing until deployed. Manual `cp` is wrong — use the deploy script.

**How to apply:** After ANY change to `plans/project/somewm-shell/**`:
1. `~/git/github/somewm/plans/project/somewm-shell/deploy.sh`
2. Kill QS + clean locks + clear cache + respawn:
   ```bash
   pkill -f "qs -c somewm"; rm -rf /run/user/1000/quickshell/by-id/* /run/user/1000/quickshell/by-pid/* /run/user/1000/quickshell/by-path/* ~/.cache/quickshell/qmlcache; sleep 1; somewm-client eval 'return require("awful").spawn("qs -c somewm -n -d")'
   ```
