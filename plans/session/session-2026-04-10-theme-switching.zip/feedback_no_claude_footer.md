---
name: no Claude Code footer in PRs
description: Never add "Generated with Claude Code" footer to upstream PRs
type: feedback
---

Do not add the "🤖 Generated with Claude Code" footer to PRs submitted to upstream (trip-zip/somewm).

**Why:** User prefers not to advertise AI tooling in upstream contributions.

**How to apply:** When creating PRs with `gh pr create`, omit the Claude Code footer line.
