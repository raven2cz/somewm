---
name: Never deploy untested code to live compositor
description: CRITICAL — never deploy or reload live compositor with untested changes, always use nested sandbox first
type: feedback
---

NEVER deploy untested config to live compositor. NEVER run `somewm-client reload` or `deploy.sh` with untested changes on the running session.

**Why:** On 2026-04-08, I deployed untested wallpaper/theme service changes directly to the live compositor via `deploy.sh` + `somewm-client reload` and it crashed the user's entire session. The user lost their working environment.

**How to apply:**
1. ALWAYS test in nested sandbox FIRST (see CLAUDE.md "Nested compositor sandbox" section)
2. The sandbox flow is:
   - Build: `make build-test`
   - Prepare isolated config: `cp -r ~/.config/somewm /tmp/somewm-sandbox-config/somewm/`
   - Copy NEW files into the sandbox config (not the live one!)
   - Launch nested: `WLR_BACKENDS=wayland XDG_CONFIG_HOME=/tmp/somewm-sandbox-config SOMEWM_SOCKET=/run/user/1000/somewm-socket-test ./build-test/somewm -d`
   - Test IPC against sandbox: `SOMEWM_SOCKET=/run/user/1000/somewm-socket-test somewm-client eval ...`
3. Only after sandbox verification passes, ask the user before deploying to live
4. NEVER auto-deploy + reload without explicit user confirmation
