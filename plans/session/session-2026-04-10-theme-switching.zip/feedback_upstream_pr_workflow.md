---
name: upstream PR workflow
description: How to create clean PRs for trip-zip/somewm upstream — must branch from upstream/main, not our fork's main
type: feedback
---

Never create upstream PRs from branches based on our fork's main (raven2cz/somewm).
Our main diverges from upstream with extra commits (shell, configs, etc.) that would pollute the PR.

**Correct workflow:**
1. Develop and test on a branch from our main (e.g., `fix/foo`)
2. Merge to our main, verify everything works
3. Create a NEW clean branch from `upstream/main`: `git checkout upstream/main && git checkout -b fix/foo-upstream`
4. Cherry-pick or manually apply ONLY the relevant fix commits (no shell, no config, no plans)
5. Push this clean branch to `origin` (our fork)
6. Create PR from `raven2cz:fix/foo-upstream` → `trip-zip:main`
7. Delete the old development branch

**Why:** Our fork has divergent commits (quickshell, somewm-one, plans, etc.) that must never appear in upstream PRs. A clean branch from upstream/main ensures the PR diff contains only the fix.

**How to apply:** Every time we want to submit a fix upstream, follow this workflow. Never shortcut by PRing from our main or a branch based on it.
