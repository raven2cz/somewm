---
name: Auto deploy and restart QS
description: User wants deploy.sh + QS restart done automatically after shell changes, not asked about it
type: feedback
---

Always deploy and restart QS automatically after making somewm-shell changes. User tests manually.

**Why:** User said "deploy a restart qs udelej vzdy sam a ja to testnu vzdy" — they don't want to be asked, just do it.

**How to apply:** After any edit to plans/project/somewm-shell/ files, run:
```bash
plans/project/somewm-shell/deploy.sh
rm -rf ~/.cache/quickshell/qmlcache/ && kill $(pgrep -f 'qs -c somewm')
```
QS auto-respawns via awful.spawn.once in rc.lua.
