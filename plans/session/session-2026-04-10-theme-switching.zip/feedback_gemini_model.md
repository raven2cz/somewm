---
name: Gemini CLI correct model
description: Always use gemini-3.1-pro-preview model with gemini CLI, never gemini-2.5-pro or other versions
type: feedback
---

Always use `gemini-3.1-pro-preview` as the model for Gemini CLI reviews.

**Why:** User has corrected this multiple times. The correct invocation is:
```bash
cat diff.patch | gemini -m gemini-3.1-pro-preview -p "prompt"
```

**How to apply:** Every time you invoke `gemini` CLI, use `-m gemini-3.1-pro-preview`. Never guess other model names.
