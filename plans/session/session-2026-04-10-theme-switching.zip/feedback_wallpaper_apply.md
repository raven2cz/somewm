---
name: wallpaper apply — never reuse widget
description: apply_wallpaper must create a new awful.wallpaper object each time, not reuse imagebox widget
type: feedback
originSessionId: 4c00f162-14f4-4ed7-af0a-8e15e7c40a8c
---
Never "optimize" apply_wallpaper by reusing the imagebox widget and calling repaint().
Always create a fresh `awful.wallpaper { screen = scr, widget = {...} }` each time.

**Why:** Reusing the widget + manual repaint() fixes the visual wallpaper but breaks client animation timing during tag slide transitions. The awful.wallpaper constructor handles more than just repaint — screen binding, previous wallpaper replacement, scene graph updates — and these are needed for tag_slide overlays to work correctly.

**How to apply:** In fishlive/services/wallpaper.lua `apply_wallpaper()`, always create a new awful.wallpaper object. The `scr._current_wallpaper` path dedup guard is fine, but don't cache/reuse the widget or wallpaper object.
