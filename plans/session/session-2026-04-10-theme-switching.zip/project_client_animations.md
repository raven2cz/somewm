---
name: project_client_animations
description: Client animation module status — scenefx integration complete, all phases done, upstream issue pending
type: project
---

Client animation module (`plans/project/somewm-one/anim_client.lua`) on `feat/scenefx-integration`.

**All phases COMPLETED (22 commits):**
- Phase 1: Build integration (scenefx as optional dep, `-Dscenefx=auto`)
- Phase 2: Rounded corners (corner_radius property, commitnotify re-apply)
- Phase 3: GPU shadows (scenefx native shadow nodes, dual-path with 9-slice fallback)
- Phase 4: Opacity (no change needed — wlroots reset confirmed, keep re-apply hacks)
- Phase 5: Backdrop blur (per-client property, blur_data global config)
- Phase 6: Rounded border frame (single rect + clipped_region, replaces 4-rect borders)
- Phase 7: Titlebar rounded corners (per-bar corner_location, cr+1 SDF overlap fix)
- Phase 8: Fade + decoration interaction (hide border/shadow/blur during fade)

**Known issue — fadeIn + blur_opacity interaction (NOT FIXED):**
- ghostty class is `com.mitchellh.ghostty`, blur rule matches via Lua pattern match
- FadeIn hardcodes `to_alpha=1.0`, overrides ruled.client `blur_opacity=0.75`
- **Why:** Complex interaction between ruled.client, request::manage, commitnotify opacity re-apply
- **How to apply:** Don't attempt quick fixes — needs full opacity lifecycle analysis first

**Next step:** Create upstream issue with video demo referencing this branch.
Plans doc at `plans/scenefx-integration.md` fully updated with all phases.
