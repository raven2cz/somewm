---
name: feedback_install_script
description: Always use install-scenefx.sh for building and installing, never sudo make install
type: feedback
---

Always use `~/git/github/somewm/plans/install-scenefx.sh` to build and install somewm.

**Why:** `sudo make install` uses the ASAN dev build directory without SceneFX. The install-scenefx.sh script builds with `-Dscenefx=enabled` into `build-fx/`, runs ldconfig for `libscenefx-0.4.so`, and installs correctly to `/usr/local`.

**How to apply:** When suggesting build/install commands to the user, always reference `install-scenefx.sh`. Never suggest `sudo make install` or `ninja -C build && sudo make install`.
