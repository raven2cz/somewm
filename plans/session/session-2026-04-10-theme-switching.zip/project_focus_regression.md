---
name: Focus/pointer regression from upstream merge
description: After upstream sync (9b543b0), pointer focus and keyboard focus have regressions - scroll doesn't work without clicking, sloppy focus broken
type: project
---

After merging upstream/main (commit 9b543b0), two focus regressions appeared:

1. **Pointer focus / scroll broken**: Moving mouse over a window (e.g. Dolphin) doesn't deliver pointer focus — scroll wheel doesn't work until user clicks. This means `pointerfocus()` or `wlr_seat_pointer_notify_enter()` isn't being called/working correctly on mouse motion.

2. **Keyboard focus desync (again)**: Upstream rewrote `some_set_seat_keyboard_focus()` in somewm_api.c. Key change: `client_activate_surface()` calls for deactivate/activate were restricted to X11-only. XDG (native Wayland) clients no longer get activated/deactivated on focus change. Our original fix (292159b) had this for ALL client types.

**Why:** Upstream PR #247 (merged) cherry-picked our keyboard focus fix but then refactored it. The POINTER FOCUS is the primary issue — user can't scroll in windows without clicking first. This worked before the upstream merge (9b543b0).

**Investigation done so far:**
- `pointerfocus()` at somewm.c:4103 IS called from motionnotify — no early return blocks it
- `pointerfocus()` calls `wlr_seat_pointer_notify_enter()` at line 4251 — this should work
- The `some_is_lua_locked()` guard (new from upstream) returns false normally
- `xytonode()` at line 3865 runs before `wlr_cursor_move()` — uses OLD cursor position. But this was always the case (dwl pattern), not a regression.
- New drag handling (lines 3924-3936) does early return but only during active drag
- `client_activate_surface()` was restricted to X11-only (somewm_api.c:494-521) — this is for keyboard path, not pointer

**How to apply:** Next session should:
1. Focus ONLY on POINTER focus — the user's primary complaint is scroll/mouse not working without click
2. Add debug logging to `pointerfocus()` to verify it's being called with correct surface
3. Check `wlr_seat_pointer_notify_enter()` — is the surface actually receiving pointer enter?
4. Check upstream gesture support (10b4f74) — swipe/hold gesture listeners might intercept pointer events
5. Check `some_notify_activity()` (new from upstream) — does it have side effects?
6. Compare `axisnotify()` before/after merge — upstream added gesture consumed check
7. Test: run `WAYLAND_DEBUG=1` to see actual protocol-level pointer.enter events
8. Key question: is the FIRST mouse::enter after switching to a window being suppressed somehow?
9. Check Sway's pointer focus delivery for comparison

**Uncommitted aspect ratio fix** (for mpv) needs content-area calculation — was working on it but reverted. The C code enforces ratio on full geometry (incl borders/titlebars) but should work on content area only. Fix was in somewm.c:4539 and objects/client.c:2773.
